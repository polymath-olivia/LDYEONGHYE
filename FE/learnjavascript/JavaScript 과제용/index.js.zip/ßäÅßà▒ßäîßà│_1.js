// function add(a, b) {
// 	return a + b;
// }

// 여기에 화살표 함수로 다시 작성하세요.
const add = (a, b) => {
    return a + b;
};

console.log(add(5, 3)); // 예상 결과: 8