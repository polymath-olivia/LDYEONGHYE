// 여기에 두 개의 parameter를 가진 화살표 함수를 작성하세요.
const minus = (a, b) => {
    return a - b;
}

// 함수 테스트
console.log(minus(60, 20));// 예상 결과: 40
