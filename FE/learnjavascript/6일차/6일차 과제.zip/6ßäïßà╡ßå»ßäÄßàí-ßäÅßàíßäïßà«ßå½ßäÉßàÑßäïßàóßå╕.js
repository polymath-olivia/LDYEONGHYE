const counterEl = document.querySelector(".counter");
const increaseButtonEl = document.querySelector(".increase-button");
const decreaseButtonEl = document.querySelector(".decrease-button");

let count = 0;
const minCount = 0;
const maxCoount = 10;

console.log("🚀 ~ counterEl:", counterEl);

const updateDisplay = () => {
  counterEl.innerText = count;
};

const increase = () => {
  if (count < maxCoount) {
    count = count + 1;
    updateDisplay();
  }
};

const decrease = () => {
  if (count > minCount) {
    count -= 1;
    updateDisplay();
  }
};

increaseButtonEl.addEventListener("click", increase);
decreaseButtonEl.addEventListener("click", decrease);
